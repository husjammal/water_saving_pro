import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import 'package:logger/logger.dart';

class LiveChartsScreen extends StatefulWidget {
final Stream<List<dynamic>> liveDataStream;

const LiveChartsScreen({super.key, required this.liveDataStream});

@override
State<LiveChartsScreen> createState() => _LiveChartsScreenState();
}

class _LiveChartsScreenState extends State<LiveChartsScreen> {
final Logger _logger = Logger();
final List<FlSpot> _tapDurationSpots = [];
final List<FlSpot> _batteryVoltageSpots = [];
final List<FlSpot> _waterFlowSpots = [];
int? _firstTimestamp;
final List<List<dynamic>> _liveData = [];
StreamSubscription<List<dynamic>>? _streamSubscription;

@override
void initState() {
super.initState();
_streamSubscription = widget.liveDataStream.listen((data) {
_processLiveData(data);
}, onError: (e) {
_logger.e('Stream error: $e');
});
}

void _processLiveData(List<dynamic> row) {
if (row.length != 4) {
_logger.w('Invalid live data row, expected 4 fields, got ${row.length}: $row');
return;
}
try {
int timestamp = row[0] as int;
double waterFlow = row[1] as double;
double batteryVoltage = row[2] as double;
double tapDuration = row[3] as double;

if (!mounted) {
_logger.w('Widget not mounted, skipping setState for row: $row');
return;
}

setState(() {
_liveData.add(row);
_firstTimestamp ??= timestamp;

if (_liveData.length > 120) {
_liveData.removeAt(0);
_tapDurationSpots.removeAt(0);
_batteryVoltageSpots.removeAt(0);
_waterFlowSpots.removeAt(0);
}

double secondsSinceFirst = (timestamp - _firstTimestamp!).toDouble();
_tapDurationSpots.add(FlSpot(secondsSinceFirst, tapDuration));
_batteryVoltageSpots.add(FlSpot(secondsSinceFirst, batteryVoltage));
_waterFlowSpots.add(FlSpot(secondsSinceFirst, waterFlow));

_logger.d('Added live FlSpot: seconds=$secondsSinceFirst, tapDuration=$tapDuration, batteryVoltage=$batteryVoltage, waterFlow=$waterFlow');
});

if (_tapDurationSpots.every((spot) => spot.y == 0)) {
_logger.w('All live tap durations are 0.0; check data source');
}
if (_waterFlowSpots.every((spot) => spot.y == 0)) {
_logger.w('All live water flow rates are 0.0; check data source');
}
} catch (e) {
_logger.e('Error processing live data row: $row, Error: $e');
}
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(title: const Text('Live Charts')),
body: SingleChildScrollView(
padding: const EdgeInsets.all(16.0),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
const Text('Water Flow Rate (L/s)', style: TextStyle(fontSize: 18)),
Container(
height: 200,
padding: const EdgeInsets.all(8.0),
child: _waterFlowSpots.isEmpty || _waterFlowSpots.every((spot) => spot.y == 0)
? const Center(child: Text('No water flow data available'))
    : LineChart(
LineChartData(
lineBarsData: [
LineChartBarData(
spots: _waterFlowSpots,
isCurved: true,
color: Colors.orange,
dotData: const FlDotData(show: false),
),
],
titlesData: FlTitlesData(
leftTitles: const AxisTitles(
sideTitles: SideTitles(showTitles: true, reservedSize: 40),
),
bottomTitles: AxisTitles(
sideTitles: SideTitles(
showTitles: true,
getTitlesWidget: (value, meta) {
if (_firstTimestamp == null) return const Text('');
final seconds = value.toInt();
return Text(
DateFormat('mm:ss').format(
DateTime.fromMillisecondsSinceEpoch(
(_firstTimestamp! + seconds) * 1000,
),
),
);
},
),
),
topTitles: const AxisTitles(),
rightTitles: const AxisTitles(),
),
gridData: const FlGridData(show: true),
borderData: FlBorderData(show: true),
),
),
),
const SizedBox(height: 20),
const Text('Tap-On Duration (seconds)', style: TextStyle(fontSize: 18)),
Container(
height: 200,
padding: const EdgeInsets.all(8.0),
child: _tapDurationSpots.isEmpty || _tapDurationSpots.every((spot) => spot.y == 0)
? const Center(child: Text('No tap duration data available'))
    : LineChart(
LineChartData(
lineBarsData: [
LineChartBarData(
spots: _tapDurationSpots,
isCurved: true,
color: Colors.blue,
dotData: const FlDotData(show: false),
),
],
titlesData: FlTitlesData(
leftTitles: const AxisTitles(
sideTitles: SideTitles(showTitles: true, reservedSize: 40),
),
bottomTitles: AxisTitles(
sideTitles: SideTitles(
showTitles: true,
getTitlesWidget: (value, meta) {
if (_firstTimestamp == null) return const Text('');
final seconds = value.toInt();
return Text(
DateFormat('mm:ss').format(
DateTime.fromMillisecondsSinceEpoch(
(_firstTimestamp! + seconds) * 1000,
),
),
);
},
),
),
topTitles: const AxisTitles(),
rightTitles: const AxisTitles(),
),
gridData: const FlGridData(show: true),
borderData: FlBorderData(show: true),
),
),
),
const SizedBox(height: 20),
const Text('Battery Voltage (V)', style: TextStyle(fontSize: 18)),
Container(
height: 200,
padding: const EdgeInsets.all(8.0),
child: _batteryVoltageSpots.isEmpty
? const Center(child: Text('No battery voltage data available'))
    : LineChart(
LineChartData(
lineBarsData: [
LineChartBarData(
spots: _batteryVoltageSpots,
isCurved: true,
color: Colors.green,
dotData: const FlDotData(show: false),
),
],
titlesData: FlTitlesData(
leftTitles: const AxisTitles(
sideTitles: SideTitles(showTitles: true, reservedSize: 40),
),
bottomTitles: AxisTitles(
sideTitles: SideTitles(
showTitles: true,
getTitlesWidget: (value, meta) {
if (_firstTimestamp == null) return const Text('');
final seconds = value.toInt();
return Text(
DateFormat('mm:ss').format(
DateTime.fromMillisecondsSinceEpoch(
(_firstTimestamp! + seconds) * 1000,
),
),
);
},
),
),
topTitles: const AxisTitles(),
rightTitles: const AxisTitles(),
),
gridData: const FlGridData(show: true),
borderData: FlBorderData(show: true),
),
),
),
],
),
),
);
}

@override
void dispose() {
_streamSubscription?.cancel();
_logger.i('LiveChartsScreen disposed, stream subscription cancelled');
super.dispose();
}
}